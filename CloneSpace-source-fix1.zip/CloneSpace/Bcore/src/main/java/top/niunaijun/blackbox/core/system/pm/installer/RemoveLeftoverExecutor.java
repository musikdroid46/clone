package top.niunaijun.blackbox.core.system.pm.installer;

import java.io.File;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

import top.niunaijun.blackbox.core.env.BEnvironment;
import top.niunaijun.blackbox.core.system.accounts.BAccountManagerService;
import top.niunaijun.blackbox.core.system.pm.BPackageSettings;
import top.niunaijun.blackbox.entity.pm.InstallOption;
import top.niunaijun.blackbox.utils.FileUtils;
import top.niunaijun.blackbox.utils.Slog;

/**
 * Membersihkan sisa aplikasi yang tidak ikut terhapus oleh RemoveUserExecutor,
 * supaya "hapus data" / uninstall hasilnya mendekati uninstall + install ulang:
 * obb, Android/media, profil ART, akun di AccountManager virtual, dan folder
 * di /sdcard virtual yang namanya sama dengan paket aplikasi.
 */
public class RemoveLeftoverExecutor implements Executor {
    private static final String TAG = "RemoveLeftoverExecutor";

    // Folder umum yang dipakai bersama banyak aplikasi, tidak boleh dihapus.
    private static final Set<String> PROTECTED = new HashSet<>(Arrays.asList(
            "android", "download", "downloads", "dcim", "pictures", "movies", "music",
            "documents", "alarms", "notifications", "ringtones", "podcasts", "audiobooks",
            "recordings", "screenshots"));

    @Override
    public int exec(BPackageSettings ps, InstallOption option, int userId) {
        String pkg = ps.pkg.packageName;
        try {
            FileUtils.deleteDir(BEnvironment.getExternalObbDir(pkg, userId));
            FileUtils.deleteDir(BEnvironment.getExternalMediaDir(pkg, userId));
            FileUtils.deleteDir(BEnvironment.getProfilesCurDir(pkg, userId));
            FileUtils.deleteDir(BEnvironment.getProfilesRefDir(pkg, userId));
        } catch (Throwable t) {
            Slog.w(TAG, "delete obb/media/profiles failed: " + pkg, t);
        }

        try {
            deleteSdcardFolders(pkg, userId);
        } catch (Throwable t) {
            Slog.w(TAG, "delete sdcard folders failed: " + pkg, t);
        }

        try {
            BAccountManagerService.get().removeAccountsOfPackage(pkg, userId);
        } catch (Throwable t) {
            Slog.w(TAG, "remove accounts failed: " + pkg, t);
        }
        // Pembersihan tambahan bersifat best-effort, tidak boleh menggagalkan uninstall/clear.
        return 0;
    }

    private void deleteSdcardFolders(String pkg, int userId) {
        File root = BEnvironment.getExternalUserDir(userId);
        File[] children = root.listFiles();
        if (children == null) {
            return;
        }
        String full = pkg.toLowerCase(Locale.ROOT);
        String last = full.substring(full.lastIndexOf('.') + 1);
        for (File child : children) {
            if (!child.isDirectory()) {
                continue;
            }
            String name = child.getName().toLowerCase(Locale.ROOT);
            if (PROTECTED.contains(name)) {
                continue;
            }
            if (name.equals(full) || (last.length() >= 4 && name.equals(last))) {
                Slog.d(TAG, "delete sdcard folder: " + child.getAbsolutePath());
                FileUtils.deleteDir(child);
            }
        }
    }
}
